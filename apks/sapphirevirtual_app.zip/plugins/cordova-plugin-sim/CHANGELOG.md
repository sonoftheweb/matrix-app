# Changelog

## v1.3.3

- Android: Adjust required API levels
- iOS: add CoreTelephony imports
- docs: Ionic 2 Usage
- docs: API level 25 codes

## v1.3.2

- Android: use Cordova Permissions API
- Android: drop Android Support Library requirement

## v1.3.1

- Android: callbacks for requestReadPermission()

## v1.3.0

- add multiple SIM support on Android

## v1.2.1

- separate Android-related javascript methods

## v1.2.0

- handle Android API 23 Permissions

## v1.1.0

- add new properties on Android

## v1.0.1

- rename plugin to follow new cordova plugin naming conventions

## v1.0.0

- initial release
